from django.views.generic import ListView, DetailView
from django.conf.urls import *
from tager_www.models import *
from tager_www.views import *

