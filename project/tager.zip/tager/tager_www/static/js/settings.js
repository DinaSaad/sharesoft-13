$(function(){
  $('#container').masonry({
    // options
    itemSelector : '.item',
    columnWidth : 240,
    isAnimated: true
  });
});