$(document).ready(function(){
$('#Channel_dropdown').change(function(){
	window.location.replace("viewsubchannels?ch_id="+$(this).val())
});
});


#$(document).ready(function(){
#$('#subChannel_dropdown').change(function(){
#	window.location.replace("att?sub_ch_id="+$(this).val())
#});
#});


